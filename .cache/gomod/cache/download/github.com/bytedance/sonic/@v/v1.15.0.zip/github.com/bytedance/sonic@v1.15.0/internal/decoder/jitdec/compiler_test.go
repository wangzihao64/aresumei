/*
 * Copyright 2021 ByteDance Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package jitdec

import (
	"reflect"
	"testing"

	"github.com/bytedance/sonic/internal/encoder/vars"
	"github.com/stretchr/testify/assert"
)

func TestCompiler_Compile(t *testing.T) {
    prg, err := newCompiler().compile(reflect.TypeOf(TwitterStruct{}))
    assert.Nil(t, err)
    prg.disassemble()
}

func BenchmarkCompiler_Compile(b *testing.B) {
    for i := 0; i < b.N; i++ {
        pp, err :=  newCompiler().compile(reflect.TypeOf(TwitterStruct{}))
        if err != nil {
            panic("compile failed")
        } 
        as := newAssembler(pp)
        as.name = "twitter struct"
        _ = as.Load()
        vars.ResetProgramCache()
    }
}
